
document.getElementById('img-0').src = MEDIA_DATA.images[0];
document.getElementById('img-1').src = MEDIA_DATA.images[1];
document.getElementById('img-2').src = MEDIA_DATA.images[2];
document.getElementById('bgMusic').src = MEDIA_DATA.audio;
